/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_rev_params.c                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ssundara <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/06/26 20:29:25 by ssundara          #+#    #+#             */
/*   Updated: 2018/06/27 13:15:58 by ssundara         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int		ft_putchar(char c);

void	print_arr(char *arr)
{
	char	*s;

	s = arr;
	while (*s != '\0')
	{
		ft_putchar(*s);
		s++;
	}
}

void	print_params_reverse(int argc, char *argv[])
{
	int i;

	i = argc - 1;
	while (i > 0)
	{
		print_arr(argv[i]);
		ft_putchar('\n');
		i--;
	}
}

int		main(int argc, char *argv[])
{
	print_params_reverse(argc, argv);
	return (0);
}
